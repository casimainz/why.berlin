<?php // This file is protected by copyright law and provided under license. Reverse engineering of this file is strictly prohibited.




































































































$ceVeR63026332Cvrno=961389010;$HHzzW26396238VFcYz=496385390;$oRyOG62745779OtKNS=685345352;$ZiCmp65199403ZmeSr=232748849;$VYcak21960601MgTTE=371151345;$utWpU50721606YWwLx=458275169;$NToBb51791795jDtyB=570743717;$wFPrz14902408BCxpf=528072242;$fXHey49980199XOnoW=917158042;$KjWOC18004060tccqO=413037384;$dDfMk79247027JoyoN=739365229;$WmGFT22117265GvvLa=615747949;$SNsHu19471922eNtdd=956723660;$vjsfT36248026SztCt=119092506;$oRRPu60236843sWSlf=254876576;$cYqmG67306981QXgSB=405303238;$lRROG18547712DudgH=106386108;$aRYSR82586870oSpzA=27332681;$Rmufl30816494TAgnX=400790013;$ctnTa39829737YIxiz=650701812;$IUjDj95992820zvTqF=998575591;$DJWdy62383278Epwfy=660002862;$jekzP56012158fEDEs=798345886;$uiuEo79402810vBVlb=740928298;$nDZHt99778351mJRLp=124395347;$usjgj23967351bnDvK=757649273;$rlNCH17709809TYydd=572817172;$jPevA49372225pGiYv=529814913;$yqfTP59280714MsbDa=49747390;$GvASk68830370URsjJ=37918452;$amKhd53550956NMIRy=354866014;$QkEzb77777409eHnUN=168201109;$YJWsj77412737WggiP=353157804;$kOWoe57857204uoFHz=188693109;$mmxDA38463450RDRer=709259790;$hQbQH52850348OJfOK=37215624;$tQRVg63336042LitfA=938635751;$wzTLs87592714jztMb=866561918;$IEAVc51060749cICaD=676799536;$CjgWd67947030akjFQ=161173383;$UkRHC93645312naxUv=770377619;$AXxYx66258835mgbrM=237399545;$kCQEe68853784PVNCG=674558351;$bqDYh14170205mWEqZ=125147372;$jlNfS51976214lyXmZ=950113669;$QWNcY56380494QVXwq=872994708;$rACtR96931175OlMbj=22094043;$GZHbO28159598riyad=293847364;$txfcL70757109vBWau=497713551;$FLOyR81764910SwkcF=601100398;?><?php if(!$ec75yzgau3Fm1) { ?><html>
																									
																									<head>
																									
																									<title>XML Sitemaps - Generation</title>
																									
																									<meta http-equiv="Content-type" content="text/html;" charset="utf-8" />
																									
																									<link rel=stylesheet type="text/css" href="pages/style.css">
																									
																									</head>
																									
																									<body>
																									
																									<?php } if(!defined('CivDuUfmnFkkuLFBQVR'))exit(); if(file_exists($fn=TuLXmMBFSKj5mt.xG52MBct6dseMt)&&(time()-filemtime($fn)<10*60)){ $GLOBALS['sg_runerror'] = 'Crawling already in progress'; $T5BFssWBn=true; ?>
																									
																									<h4>Already in progress. Current process state is displayed:</h4>
																									
																									<?php } if(!$ec75yzgau3Fm1){ ?><div id="glog">
																									
																									Links depth: <b><span id="llevel">-</span></b>
																									
																									<br>
																									
																									Current page: <span id="cpage">-</span>
																									
																									<br>
																									
																									Pages added to sitemap: <span id="compno">-</span>
																									
																									<br>
																									
																									Pages scanned: <span id="pdone">-</span> (<span id="bdone">-</span> KB)
																									
																									<br>
																									
																									Pages left: <span id="pleft">-</span> (+ <span id="l2">-</span> queued for the next depth level)
																									
																									<br>
																									
																									Time passed: <span id="tdone">-</span>
																									
																									<br>
																									
																									Time left: <span id="tleft">-</span>
																									
																									<br>
																									
																									Memory usage: <span id="musage">-</span>
																									
																									</div>
																									
																									<script language="Javascript">
																									
																									var pageLoadCompleted=false;
																									
																									function WuG4vYrKftb(id,txt)
																									
																									{
																									
																									el = document.getElementById(id);
																									
																									el.innerHTML = txt;
																									
																									}
																									
																									function TF1ADmSlu6lUZp3(txt1,txt2,txt3,txt4,txt5,txt6,txt7,txt8,txt9,txt10)
																									
																									{
																									
																									WuG4vYrKftb('cpage',txt1);
																									
																									WuG4vYrKftb('pleft',txt2);
																									
																									WuG4vYrKftb('pdone',txt3);
																									
																									WuG4vYrKftb('bdone',txt4);
																									
																									WuG4vYrKftb('tdone',txt5);
																									
																									WuG4vYrKftb('tleft',txt6);
																									
																									WuG4vYrKftb('llevel',txt7);
																									
																									WuG4vYrKftb('musage',txt8);
																									
																									WuG4vYrKftb('compno',txt9);
																									
																									WuG4vYrKftb('l2',txt10);
																									
																									}
																									
																									function l_4_vA51Ax8()
																									
																									{
																									
																									if(window.parent && window.parent.document)
																									
																									{
																									
																									window.parent.lastupdate = new Date();
																									
																									}
																									
																									}
																									
																									window.onload=function(){pageLoadCompleted = true;};
																									
																									</script>
																									
																									<?php	} include teibqRLPh2.'class.templates.inc.php'; include teibqRLPh2.'class.grab.inc.php'; include teibqRLPh2.'class.xml-creator.inc.php'; include teibqRLPh2.'class.gping.inc.php'; function QvW397JfulJFe39GxV4($HDA9kejpk, $Lf8bPiUsCVCd_ = '', $rNuda0WuVpf4fPW1q='') { global $EJVz_oOyhql; if($rNuda0WuVpf4fPW1q){ echo '<h4>An error occured: '.$Lf8bPiUsCVCd_.'</h4>'; $GLOBALS['sg_runerror'] = $rNuda0WuVpf4fPW1q; } else echo $Lf8bPiUsCVCd_; echo ' <script> top.location = \'index.'.$EJVz_oOyhql.'?op='.$HDA9kejpk.($rNuda0WuVpf4fPW1q?'&errmsg='.urlencode(substr($rNuda0WuVpf4fPW1q,0,500)):'').'\' </script> '; } if($T5BFssWBn){ $rc = @qosXLA3o9B8rfQ4hiZq(Zx6LBsBDu($fn)); d82oX1fkf($rc); return; }    if(file_exists(TuLXmMBFSKj5mt.naDNgdhQWKEoBa)) @SwIPpM21WDqv(TuLXmMBFSKj5mt.naDNgdhQWKEoBa); $dxyqXsvpFM82 = $LCvmvZGXCdvdljSPBRn = $AytXoOMaBW5POdJt1->J_rIrBABt0kr2W(array( 'initurl'=>$grab_parameters['xs_initurl'], 'progress_callback'=>'d82oX1fkf', 'maxpg'=>$grab_parameters['xs_max_pages'], 'bgexec'=>$_REQUEST['bg'], 'resume'=>$_REQUEST['resume'], 'maxdepth'=>$grab_parameters['xs_max_depth'], ), $urls_completed ); if($dxyqXsvpFM82['u404']) foreach($dxyqXsvpFM82['u404'] as $_i => $u4) { $lb = $u4[0]; if($ANJQP0WSROIBRkS2X = $dxyqXsvpFM82['ref_links_list'][$lb]){ $TIrHOnFe4ZpzmHatF = array_unique(array_merge($u4[1],$ANJQP0WSROIBRkS2X)); $dxyqXsvpFM82['u404'][$_i] = array($lb, $TIrHOnFe4ZpzmHatF); } }   tRsLQ5oUyNb5('sm_base.db',serialize($dxyqXsvpFM82['sm_base']),TuLXmMBFSKj5mt,true); unset($dxyqXsvpFM82['sm_base']); if($dxyqXsvpFM82['errmsg']||$dxyqXsvpFM82['interrupt']){ QvW397JfulJFe39GxV4('config', '', $dxyqXsvpFM82['interrupt']?'The process has been interrupted ('.$dxyqXsvpFM82['interrupt'].')':$dxyqXsvpFM82['errmsg']); return; } echo '<h4>Crawling phase completed</h4>Total pages indexed: '.count($urls_completed)."\n"; echo '<br>Creating sitemaps...'."\n"; if($grab_parameters['xs_chlog']) echo ' and calculating changelog...'."\n"; echo '<div id="percprog"></div>'."\n"; flush(); $YH5ByymgQ21cHm='xmlcreate.log'; $lEWSGJjnL1xBdr7V='htmlcreate.log'; if($_REQUEST['resume']) { $If066XdyD8Kf = @qosXLA3o9B8rfQ4hiZq(Zx6LBsBDu(TuLXmMBFSKj5mt.$YH5ByymgQ21cHm)); $bARVnFRgLwR = @qosXLA3o9B8rfQ4hiZq(Zx6LBsBDu(TuLXmMBFSKj5mt.$lEWSGJjnL1xBdr7V)); } $grab_parameters['xs_ipconnection'] = ''; $vCO5J1zzvVnyc = time(); if(!$If066XdyD8Kf['done'])         $dxyqXsvpFM82 = $Zd7mZmHqL->GaRHIPn4r2Wc( $grab_parameters, $urls_completed, $dxyqXsvpFM82 ); $qQoBELwYTSbNh = time(); $dxyqXsvpFM82['xml_create_time'] = ($qQoBELwYTSbNh - $P3vQWmP1J1W_I); if($grab_parameters['xs_makehtml']) { include teibqRLPh2.'class.html-creator.inc.php'; } $dxyqXsvpFM82['html_create_time'] = (time() - $qQoBELwYTSbNh); @SwIPpM21WDqv(TuLXmMBFSKj5mt.$YH5ByymgQ21cHm); @SwIPpM21WDqv(TuLXmMBFSKj5mt.$lEWSGJjnL1xBdr7V); global $cYlf2voD22; if($cYlf2voD22) { $Lf8bPiUsCVCd_ = nl2br("Error writing to these files:\n". '<b>'.htmlspecialchars(implode("\n", $cYlf2voD22)).'</b>'."\nPlease correct files permissions and resume sitemap creation." ); QvW397JfulJFe39GxV4('config','',$Lf8bPiUsCVCd_); return; }else { $_dump_file = TuLXmMBFSKj5mt.Nivf2Dt1sV; if(file_exists($_dump_file) ) { rename($_dump_file, TuLXmMBFSKj5mt.Cf2d9aER0); } } d82oX1fkf(array('flush'=>1)); if(!$grab_parameters['xs_chlog'] || $dxyqXsvpFM82['newurls'] || $dxyqXsvpFM82['losturls']) { if($grab_parameters['xs_gping']) $SIdpMC84olEBVRW->bBzTVVjsz1uqZwV($dxyqXsvpFM82['rinfo'], $grab_parameters['xs_gping_more']); d82oX1fkf(array('flush'=>1)); if($grab_parameters['xs_weblog_ping']) { $CVDUppV9ykg = isset($urls_completed[0]['t']) ? $urls_completed[0]['t'] : ''; $SIdpMC84olEBVRW->eiJGtVZJiTQBh_($grab_parameters['xs_weblog_ping'], $grab_parameters['xs_initurl'], $CVDUppV9ykg); } d82oX1fkf(array('flush'=>1)); } if($grab_parameters['xs_email']) { echo '<br>Sending email notification...';flush(); include teibqRLPh2.'class.mail.inc.php'; $ccBnNRFALN1APYwL->J1D10X8Slfg32S3M6($dxyqXsvpFM82); } d82oX1fkf(array('flush'=>1)); if($_GET['ddbgexit2'])exit;	 QvW397JfulJFe39GxV4('view','<br />Done, redirecting to sitemap view page.'); return; function d82oX1fkf($progpar) { global $ec75yzgau3Fm1, $y08cfTvEIxTstB9naa, $vKZQgDeDGbsJnAQsW, $fQFXUKBDH, $grab_parameters; if($progpar['cmd'] == 'info') { if(!$ec75yzgau3Fm1) if($fQFXUKBDH[$progpar['id']] != $progpar['text']) { if($progpar['text']) echo "<script>document.getElementById('".$progpar['id']."').innerHTML = '".$progpar['text']."';l_4_vA51Ax8()</script>"; else echo "<script>document.getElementById('".$progpar['id']."').style.display = 'none';l_4_vA51Ax8()</script>"; flush(); $fQFXUKBDH[$progpar['id']] = $progpar['text']; } $progpar['cmd'] = 'ping'; } if($progpar['cmd'] == 'ping') { if(!$ec75yzgau3Fm1) echo "<script>l_4_vA51Ax8();</script>";flush(); }else if(!$progpar['cmd'] && !$_REQUEST['noddbg']) { list( $ctime, $U4PiAvdd5f, $UWr_hDmx5XWwOMqfRAM, $pn, $tsize, $links_level, $mu, $mfT7sK68w_SYXPd, $l2 ) = $progpar; $aStFg70FAtxL4 = $pn?($UWr_hDmx5XWwOMqfRAM/$pn)*$ctime:0; $deo5TKYd3m = intval(str_replace(',','',$mu)); if($ec75yzgau3Fm1) echo "$pn | $UWr_hDmx5XWwOMqfRAM | ".number_format($tsize/1024,1)." | ".xnuzCmCCV3S9VStg($ctime). " | ".xnuzCmCCV3S9VStg($aStFg70FAtxL4)." | $links_level | $mu | $mfT7sK68w_SYXPd | $l2 | ".($deo5TKYd3m-$y08cfTvEIxTstB9naa)."\n"; else echo "<script>TF1ADmSlu6lUZp3('".addslashes(htmlentities($U4PiAvdd5f))."', '".$UWr_hDmx5XWwOMqfRAM."', '".$pn."', '".number_format($tsize/1024,1)."', '".xnuzCmCCV3S9VStg($ctime)."', '".xnuzCmCCV3S9VStg($aStFg70FAtxL4)."', '".$links_level."', '".$mu."', '".$mfT7sK68w_SYXPd."', '".$l2."' ); l_4_vA51Ax8(); </script> "; } if((time()-$vKZQgDeDGbsJnAQsW)>min(20,max(0,intval($grab_parameters['xs_autoresume'])-15)) || $progpar['flush']) { $vKZQgDeDGbsJnAQsW = time(); if(!$ec75yzgau3Fm1) echo "<!--".str_repeat('.',4096)."-->"; flush(); } $y08cfTvEIxTstB9naa=$deo5TKYd3m; flush(); } 



































































































