<?php // This file is protected by copyright law and provided under license. Reverse engineering of this file is strictly prohibited.




































































































$pFadH82868680QNsoU=389744611;$hcmXS27507143mPejf=629001527;$SNrjj96647413GeVza=105252148;$hGxtI22129096MxVWW=525697430;$NgfTZ19684950CPMYY=208582312;$KYEbo22436525hBfPy=853007275;$QBYCc48529677RjSMK=240292099;$tTibg99736158RmpHF=734312857;$OZBmb42404201Surtl=224474921;$sHwXK65384445vRDBT=57693199;$VWers49521608VYYtw=6420709;$oApoV98290471MrcUG=281238164;$kSEnb94746930rniDx=770958285;$TtZCl62318658wwpdw=528639313;$CoPvZ19070673CiIDj=894789954;$NAMTa26073917rytCC=661965049;$tDCOL38513540QpNLe=420327859;$NnZNe59165141cFbUG=906570071;$kfxUp88727454qWItN=963861497;$DHizV36204930sMzbf=885961539;$OUgbO50421216OVZpA=609603292;$VdaLS41606783aQGXy=331463496;$JIiGi67530320YXVEN=58045177;$vjetb20256619idfuL=96529508;$GLdtp63320227winMS=600875208;$Dsskg27954618jeaKn=625146296;$QsPUG23432110slSAa=248613123;$eQGxM39272966AfgZc=801560986;$Yxucg76798449eKqQL=603911073;$stQFq99458621NMVyk=287800021;$MmgWp72232030VEmyT=979160549;$AvAgn67170119byYxP=622421475;$HyejL63580824bKKcS=976576077;$JJESb46192755UJKgz=130832771;$BizWT62418197IKegz=491436248;$wUoMg90931886RyZsB=458328314;$JfpEX43387556WSDiz=547183175;$nzFVJ31542363phxOQ=358276503;$ytGiL39312054MnTlm=64354149;$kRZMC96287467XVgyA=985982595;$nDqXc65462218mspWD=82329095;$sOxcJ99260056Hgjzc=17630993;$hLcqA43920859gmtPv=714492296;$PdgwQ37448027IRvCU=279132859;$kFKmI91455204efECo=180113087;$wkuCu74298500vAvFW=4865863;$BEbxj51669205pkGRD=43740572;$AlnWk51425931TMOwE=85428803;$ZIwTz15222358xPmMk=958713317;$uyGLc92939585wxFBN=394084817;?><br style="clear:both;"/>
																									</div>
																									<!--<?php echo J_M_BNqIc_pALx;?>-->
																									<div id="copyright">
																									<?php include teibqRLPh2.'page-generator.inc.php';?>
																									<!--<?php echo sAI0XfHZxrZ2WX;?>-->
																									Standalone Sitemap Generator (PHP) v<?php echo $qMTZO9lk4Qd0Hn8X['version']?>, <?php echo $qMTZO9lk4Qd0Hn8X['lastupdate']?>
																									|
																									<a href="license.html">Read License</a>
																									<?php echo ($_SESSION['is_admin'])?' | <a href="index.'.$EJVz_oOyhql.'?op=logout">Logout</a>':'';?>
																									<?php if($grab_parameters['xs_checkver']){?>
																									<script type="text/javascript">
																									function djVXxnlveBkTf8(url) {
																									var s = document.createElement('script');
																									s.type = 'text/javascript';s.async = true;s.src = url;
																									var x = document.getElementsByTagName('head')[0];x.appendChild(s);
																									}
																									djVXxnlveBkTf8("https://www.xml-sitemaps.com/check-version.js?ver=<?php echo $qMTZO9lk4Qd0Hn8X['version'];?>")
																									</script>
																									<?php } ?>
																									<br />
																									Copyright (c)2005-<?php echo date('Y',strtotime($qMTZO9lk4Qd0Hn8X['lastupdate']))?> <a href="https://www.xml-sitemaps.com">XML Sitemaps</a>
																									<br style="clear:both;" />
																									</div>
																									</body>
																									</html>



































































































