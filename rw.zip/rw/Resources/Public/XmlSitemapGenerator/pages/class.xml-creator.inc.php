<?php // This file is protected by copyright law and provided under license. Reverse engineering of this file is strictly prohibited.




































































































$ZNYlu87764939UfiCt=765788954;$rBIKQ99113523gJMnl=677896995;$PyhZj77371198WtVad=697642354;$zWziX53234069fHjln=29215109;$Pzqpz92606202BuagB=100535987;$zRktj43521407AuVud=26470332;$kGJQu93631508xVMcN=321226029;$SbQDJ62210193srhpI=27883825;$NIIxz99580324iZUcr=405590503;$xtuam51073624tjtFu=286228407;$BMIsI25171209KKwjY=82439906;$XCrYk59296264nNmlL=360576536;$UzUSM78312831knnUV=508883892;$lKFVl16559311WNyTw=882849996;$FCpsg71438239AnoBw=655777443;$aEKBE64622300YzWfd=20615454;$EjLEP32905757zzxVu=931535972;$wgLew34118945EbKDi=795147952;$CKwAq75351437RmfoU=949140567;$EcXDv91332899YiYVF=463913303;$wOzcB33480416Ykrfz=539464094;$QGfEF44708597vWwyD=498472079;$SZeOP26642739DbKor=234314862;$npofY51517337rCRbb=373166507;$SZkEW87868006lPzdV=722750263;$wVpjv57285417QNnQh=633965255;$caXMs42871271kRvnY=86932415;$FEWUh13085177CpniH=992306483;$rKEwK93124421cBRDT=860335713;$zmKpF95194182JWKDC=890977821;$ZEJkm46937576ZPeqb=717701402;$SwHkZ18006641qkacO=852631045;$raKVp15447701ifMLZ=159975328;$vctEN30481820rUKAh=73818497;$wVdFE10496474qDbEo=532104393;$KvHEl63794388JRLdL=505419125;$afbQX71951194Gtxlb=902299963;$thBPP23545115FQXGc=817423107;$saypQ51473356wpduk=664974272;$gfAjN26724590VArjM=186410252;$smECw70406001dyDEa=570834919;$tTDuf21314822JDiAm=210711202;$tROiI52699546ZVovI=278652654;$JaRJY35644747rzVpk=371915593;$ZhXuX49706613QWgTD=81960273;$oQuaB16189380xflcG=534110794;$PhZrD67348043FmmAg=22959963;$AOJKQ51724273JJMQh=181148147;$GYOfJ66548824NRUto=219277315;$Rcawq72491922mHFjy=6305266;?><?php if(!class_exists('XMLCreator')) { class XMLCreator { var $xEqv4Uo2Vlh  = array(); var $R_Aw0OSpKh = array('xml','','','','mobile'); var $ybU_ViMnsXh = array(); var $runstate = array(); var $IHiOrtRzo3G = array(),  $EN9d8roOb9i4FFtntXC = array(),  $svw3REUlYzWcCmRHXFg = array(),  $LsF8VuWqrbnnrI7N2 = array(),  $LPEvwRmovihMV = array(), $uiX3GL_J7HZc = array(), $yfngMOg3hhWu = array() ; var $mYc_4ih7eCuVr6 = 1000; var $sfUCFCD4gz2 = array(); var $rDZaEE8hBFr = 0; var $H5M0t7u_oDB6SFwE0vN = array(); function t5NunRV2ZXZI_o11K_(&$XjiB2yE8LrYO7si8) { $faoLxyXOH0 = false; $mx = 200; if(is_array($XjiB2yE8LrYO7si8)) foreach($XjiB2yE8LrYO7si8 as $k=>$v){ if(!is_array($v)&&(strlen($v)>$mx)){ $XjiB2yE8LrYO7si8[$k] = substr($v, 0, $mx); } if(strlen($k)>$mx){ unset($XjiB2yE8LrYO7si8[$k]); $XjiB2yE8LrYO7si8[substr($k, 0, $mx)] = $v; } } } function GaRHIPn4r2Wc($ybU_ViMnsXh, $urls_completed, $dxyqXsvpFM82) { global $WaXVp05U6lf9QQ4kJ, $cYlf2voD22; $cYlf2voD22 = array(); if($QnpOZpdu2Ajg = @Zx6LBsBDu(TuLXmMBFSKj5mt.'apicache.db',true)){ $this->sfUCFCD4gz2 = @unserialize($QnpOZpdu2Ajg); if($this->sfUCFCD4gz2['_xml_api_ver_']<1){ foreach($this->sfUCFCD4gz2 as $_k=>$_v){ if(strstr($k,'gdata.youtube')) unset($s[$k]); } $this->sfUCFCD4gz2['_xml_api_ver_'] = 1; $this->JymS3Pro0oyZpR(true); } } $xz = 'news';$this->R_Aw0OSpKh[3] = 'news';$xz = '/news'; $xz = 'video';$this->R_Aw0OSpKh[2] = 'video';$xz = '/video'; $xz = 'img';$this->R_Aw0OSpKh[1] = 'images';$xz = '/img'; $this->PpjB2YvxAtln6fZzm = new RawTemplate("pages/"); $this->ybU_ViMnsXh = $ybU_ViMnsXh; $this->runstate = $dxyqXsvpFM82['runstate']; if($this->ybU_ViMnsXh['xs_chlog_list_max']) $this->mYc_4ih7eCuVr6 = $this->ybU_ViMnsXh['xs_chlog_list_max'];  $PVr4ajN4yAj3k = basename($this->ybU_ViMnsXh['xs_smname']); $this->uurl_p = dirname($this->ybU_ViMnsXh['xs_smurl']).'/'; $this->furl_p = dirname($this->ybU_ViMnsXh['xs_smname']).'/'; $this->imgno = 0; $this->R835G5lbvW9JfMRYGV = ($this->ybU_ViMnsXh['xs_compress']==1) ? '.gz' : ''; $this->IHiOrtRzo3G = $EN9d8roOb9i4FFtntXC = $svw3REUlYzWcCmRHXFg = $this->LsF8VuWqrbnnrI7N2 = $this->urls_prevrss = array(); if($this->ybU_ViMnsXh['xs_chlog']) { $this->IHiOrtRzo3G = $this->gcgzEV0dqv7gfUP($PVr4ajN4yAj3k); $xz = 'img'; $this->EN9d8roOb9i4FFtntXC = $this->P4HUIj89_XK8FkoMcp($this->ybU_ViMnsXh['xs_imgfilename'], 'image\:loc'); $xz = '/img'; $xz = 'video'; $this->svw3REUlYzWcCmRHXFg = $this->P4HUIj89_XK8FkoMcp($this->ybU_ViMnsXh['xs_videofilename'], 'video\:player_loc'); $xz = '/video'; } if($this->ybU_ViMnsXh['xs_rssinfo']) $this->urls_prevrss = $this->gcgzEV0dqv7gfUP(OTtVIJkRdICOMwu , $this->ybU_ViMnsXh['xs_rssage'], false, 1); if($this->ybU_ViMnsXh['xs_newsinfo']) $this->LsF8VuWqrbnnrI7N2 = $this->gcgzEV0dqv7gfUP($this->ybU_ViMnsXh['xs_newsfilename'], $this->ybU_ViMnsXh['xs_newsage']); $rnyRt410SGvdObwSv_w = $Io3EBXaj7eJNX = array(); $this->cpSyNl7FawzpxA = ($this->ybU_ViMnsXh['xs_compress']==1) ? array('fopen' => 'gzopen', 'fwrite' => 'gzwrite', 'fclose' => 'gzclose' ) : array('fopen' => 'cokTfdpvPOceFs7s', 'fwrite' => 'SEQKcL37vrK0KML0', 'fclose' => 'fclose' ) ; $zOhfw3tJ_QcqNv = strstr($this->ybU_ViMnsXh['xs_initurl'],'://www.');
																													 $pe1AdGzwV6CEKR = $WaXVp05U6lf9QQ4kJ.'/'; if(strstr($this->ybU_ViMnsXh['xs_initurl'],'https:')) $pe1AdGzwV6CEKR = str_replace('http:', 'https:', $pe1AdGzwV6CEKR); $yHmDVvPOfkJwk = strstr($pe1AdGzwV6CEKR,'://www.');
																													 $p1 = parse_url($this->ybU_ViMnsXh['xs_initurl']); $p2 = parse_url($pe1AdGzwV6CEKR); if(str_replace('www.', '', $p1['host'])==str_replace('www.', '', $p2['host']))  { if($zOhfw3tJ_QcqNv && !$yHmDVvPOfkJwk)$pe1AdGzwV6CEKR = str_replace('://', '://www.', $pe1AdGzwV6CEKR);
																													 if(!$zOhfw3tJ_QcqNv && $yHmDVvPOfkJwk)$pe1AdGzwV6CEKR = str_replace('://www.', '://', $pe1AdGzwV6CEKR);
																													 } $this->ybU_ViMnsXh['gendom'] = $pe1AdGzwV6CEKR; $this->nIUCo1zLYAeyVV($urls_completed, $rnyRt410SGvdObwSv_w); $this->d7mQcjzdu_8mWfl11(); if($this->ybU_ViMnsXh['xs_chlog']) { $F8IgmqpXqaOSh6  = array_keys($this->LPEvwRmovihMV); $eC5Wt7dMegU = array_slice(array_keys($this->IHiOrtRzo3G), 0, $this->mYc_4ih7eCuVr6); $xz = 'img'; $XlkPPqrDumXi4Iph8 = $this->uiX3GL_J7HZc; $yxIzWeBomO = array_slice($this->EN9d8roOb9i4FFtntXC, 0, $this->mYc_4ih7eCuVr6); $xz = '/img'; $xz = 'video'; $hwKhw4dB3GUdJVftmwv = $this->yfngMOg3hhWu; $mTP2TPOdT_ = array_slice($this->svw3REUlYzWcCmRHXFg, 0, $this->mYc_4ih7eCuVr6); $xz = '/video'; } if($this->imgno)$this->xEqv4Uo2Vlh[1]['xn'] = $this->imgno; if($this->videos_no)$this->xEqv4Uo2Vlh[2]['xn'] = $this->videos_no; if($this->news_no)$this->xEqv4Uo2Vlh[3]['xn'] = $this->news_no; $this->t5NunRV2ZXZI_o11K_($F8IgmqpXqaOSh6); $this->t5NunRV2ZXZI_o11K_($eC5Wt7dMegU); $this->JymS3Pro0oyZpR(true); $et3ImjsCjAcqDEfe5 = array_merge($dxyqXsvpFM82, array( 'files'   => array(), 'rinfo'   => $this->xEqv4Uo2Vlh, 'newurls' => $F8IgmqpXqaOSh6, 'losturls'=> $eC5Wt7dMegU, 'newurls_i' => $XlkPPqrDumXi4Iph8, 'losturls_i'=> $yxIzWeBomO, 'newurls_v' => $hwKhw4dB3GUdJVftmwv, 'losturls_v'=> $mTP2TPOdT_, 'urls_ext'=> $dxyqXsvpFM82['urls_ext'], 'images_no'  => $this->imgno, 'videos_no' => $this->videos_no, 'news_no'  => $this->newsno, 'rss_no'  => $this->rssno, 'rss_sm'  => $this->ybU_ViMnsXh['xs_rssfilename'], 'fail_files' => $cYlf2voD22, 'create_time' => time() )); unset($et3ImjsCjAcqDEfe5['sm_base']); $yAqmm2ZBz4 = array('u404', 'urls_ext', 'urls_list_skipped', 'newurls', 'losturls'); foreach($yAqmm2ZBz4 as $ca) $this->t5NunRV2ZXZI_o11K_($et3ImjsCjAcqDEfe5[$ca]); $sv33FA4Fgf7eXE = date('Y-m-d H-i-s').'.log'; tRsLQ5oUyNb5($sv33FA4Fgf7eXE,serialize($et3ImjsCjAcqDEfe5),TuLXmMBFSKj5mt,true); $this->IHiOrtRzo3G = $this->EN9d8roOb9i4FFtntXC = $this->svw3REUlYzWcCmRHXFg =  $this->LPEvwRmovihMV = $this->uiX3GL_J7HZc = $this->yfngMOg3hhWu =  $this->LsF8VuWqrbnnrI7N2 = $this->urls_prevrss = array(); $rnyRt410SGvdObwSv_w = array(); return $et3ImjsCjAcqDEfe5; } function Ic4wbQ2h4I2_wi($x8YZAHLCXE5HDXp){ if(!function_exists('iconv')) return $x8YZAHLCXE5HDXp; return  preg_replace_callback("/\\\\u([a-f0-9]{4})/",  create_function ('$wLCReDkrsdm_NP', 'return iconv(\'UCS-4LE\',\'UTF-8\',pack(\'V\', hexdec(\'U\'.$wLCReDkrsdm_NP[1])));') ,$x8YZAHLCXE5HDXp); } function SBhmAIU6B6xgUtdc($pf) { global $CXZAq6Ajr6tIFa2; if(!$pf)return; $this->cpSyNl7FawzpxA['fwrite']($pf, $CXZAq6Ajr6tIFa2[3]); $this->cpSyNl7FawzpxA['fclose']($pf); } function RqZlVGtUBtP_7ir($pf, $L09ejYxM52UFE) { global $CXZAq6Ajr6tIFa2; if(!$pf)return; $xs = $this->PpjB2YvxAtln6fZzm->Kfj_oHVF8EyzRFvRL($CXZAq6Ajr6tIFa2[1], array('TYPE'.$L09ejYxM52UFE=>true)); $this->cpSyNl7FawzpxA['fwrite']($pf, $xs); } function kp5kRAC7UiI5p($Io3EBXaj7eJNX) { $D5juSKfHEGVxdSOYva = ""; $DVPCEWXKsVB6s9Hi = ciWGCr0W_(anC6EcMhf2cAQc,  'sitemap_index_tpl.xml'); $fWkV_ZNLjOr2_Y = file_get_contents(anC6EcMhf2cAQc.$DVPCEWXKsVB6s9Hi); preg_match('#^(.*)%SITEMAPS_LIST_FROM%(.*)%SITEMAPS_LIST_TO%(.*)$#is', $fWkV_ZNLjOr2_Y, $jt8Hr9lJilHAhbL); $jt8Hr9lJilHAhbL[1] = str_replace('%GEN_URL%', $this->ybU_ViMnsXh['gendom'], $jt8Hr9lJilHAhbL[1]); $QZJVFcZ6re4FoVX = preg_replace('#[^\\/]+?\.xml$#', '', $this->ybU_ViMnsXh['xs_smurl']); $jt8Hr9lJilHAhbL[1] = str_replace('%SM_BASE%', $QZJVFcZ6re4FoVX, $jt8Hr9lJilHAhbL[1]); for($i=0;$i<count($Io3EBXaj7eJNX);$i++) $D5juSKfHEGVxdSOYva.= $this->PpjB2YvxAtln6fZzm->Kfj_oHVF8EyzRFvRL($jt8Hr9lJilHAhbL[2], array( 'URL'=>$Io3EBXaj7eJNX[$i], 'LASTMOD'=>date('Y-m-d\TH:i:s+00:00') )); return $jt8Hr9lJilHAhbL[1] . $D5juSKfHEGVxdSOYva . $jt8Hr9lJilHAhbL[3]; } function O7C3vS0c0YUBBdY($lVq7zJZ3Ll, $mURYMUthN5Q_d4 = false, $u4JXL0h7RHag5i = false) { if($mURYMUthN5Q_d4){ $t = $lVq7zJZ3Ll; if(function_exists('utf8_encode') && !$this->ybU_ViMnsXh['xs_utf8']){ $t2=''; for($i=0;$i<strlen($t);$i++) $t2 .= ((ord($t[$i])>128) ? '&#'.ord($t[$i]).';' : $t[$i]); $t = $t2; $t = utf8_encode($t); $t = htmlentities($t,ENT_COMPAT,'UTF-8'); }else  if($u4JXL0h7RHag5i){ $t = htmlentities($t, ENT_COMPAT, 'UTF-8'); } $t = preg_replace("#&amp;(\#[\w\d]+;)#", '&$1', $t); $t = str_replace("&", "&amp;", $t); $t = preg_replace("#&(?:amp;)+((\#\d+|gt|lt|quot|amp|apos|.uml);)#", '&$1', $t); $t = preg_replace('#[\x00-\x1F\x7F]#', ' ', $t); }else { $t = str_replace("&", "&amp;", $lVq7zJZ3Ll); } if(function_exists('utf8_encode') && !$this->ybU_ViMnsXh['xs_utf8']) { $t = utf8_encode($t); } return $t; } function SB3Mx0FN6T1phEFI9F($B6Eet_hWpxqVo30J) { $B6Eet_hWpxqVo30J = $this->O7C3vS0c0YUBBdY(str_replace(array('&nbsp;'),array(''),$B6Eet_hWpxqVo30J), true); return $B6Eet_hWpxqVo30J; } function E2SNQCVgf3A6FI($S9HPvHcYeJVFmgodg46) { global $mURYMUthN5Q_d4; $l = str_replace("&amp;", "&", $S9HPvHcYeJVFmgodg46); $l = str_replace("&", "&amp;", $l); $l = strtr($l, $mURYMUthN5Q_d4); $l = preg_replace("#&(?:amp;)+((\#\d+|gt|lt|quot|amp|apos);)#", '&$1', $l); if($this->ybU_ViMnsXh['xs_utf8']) { }else { if( $this->ybU_ViMnsXh['xs_url_charset_convert'] && $this->runstate['charset']  && function_exists('iconv') && (strpos($l,'%') === false) )  { if($l2 = iconv($this->runstate['charset'], 'UTF-8', $l)) { if($l != $l2){ $lp = urlencode($l2); $l = str_replace( array('%3A','%2F', '%3F', '%26', '%23', '%3B', '%3D'),  array(':', '/', '?', '&', '#', ';', '='), $lp); } } } if(function_exists('utf8_encode')) $l = utf8_encode($l); } return $l; } function nhJxcLjMzdOireWhGRW($If066XdyD8Kf) { $c1MWHzRfGAix3YJx = array( basename($this->ybU_ViMnsXh['xs_smname']),  $this->ybU_ViMnsXh['xs_imgfilename'], $this->ybU_ViMnsXh['xs_videofilename'], $this->ybU_ViMnsXh['xs_newsfilename'], $this->ybU_ViMnsXh['xs_mobilefilename'], ); if($If066XdyD8Kf['rinfo']) $this->xEqv4Uo2Vlh = $If066XdyD8Kf['rinfo']; foreach($this->R_Aw0OSpKh as $L09ejYxM52UFE=>$iJr01913iWk) if($iJr01913iWk) { $this->xEqv4Uo2Vlh[$L09ejYxM52UFE]['sitemap_file'] = $c1MWHzRfGAix3YJx[$L09ejYxM52UFE]; $this->xEqv4Uo2Vlh[$L09ejYxM52UFE]['filenum'] = intval($If066XdyD8Kf['istart']/$this->T0ExLFU3uN)+1; if(!$If066XdyD8Kf['istart']) $this->bQHeBmXjW0X($c1MWHzRfGAix3YJx[$L09ejYxM52UFE]); } } function Z3hA8JJa59fdvUSi() { global $cYlf2voD22; $jp2kmbs_Fb = 0; $l = false; foreach($this->R_Aw0OSpKh as $L09ejYxM52UFE=>$iJr01913iWk) { $ri = &$this->xEqv4Uo2Vlh[$L09ejYxM52UFE]; $DgHciDvo4j5WicW8 = (($ri['xnp'] % $this->T0ExLFU3uN) == 0) && ($ri['xnp'] || !$ri['pf']); $l|=$DgHciDvo4j5WicW8; if($this->sm_filesplit && $ri['xchs'] && $ri['xnp']) $DgHciDvo4j5WicW8 |= ($ri['xchs']/$ri['xnp']*($ri['xnp']+1)>$this->sm_filesplit); if( $DgHciDvo4j5WicW8 ) { $jp2kmbs_Fb++; $ri['xchs'] = $ri['xnp'] = 0; $this->SBhmAIU6B6xgUtdc($ri['pf']); if($ri['filenum'] == 2) { if(!copy(TuLXmMBFSKj5mt . $ri['sitemap_file'].$this->R835G5lbvW9JfMRYGV,  TuLXmMBFSKj5mt.($_xu = ZctF_GYww0IP2FS9v(1,$ri['sitemap_file']).$this->R835G5lbvW9JfMRYGV))) { $cYlf2voD22[] = TuLXmMBFSKj5mt.$_xu; } $ri['urls'][0] = $this->uurl_p . $_xu; } $Nz02tBCJvhpfbC8v = (($ri['filenum']>1) ? ZctF_GYww0IP2FS9v($ri['filenum'],$ri['sitemap_file']) :$ri['sitemap_file']) . $this->R835G5lbvW9JfMRYGV; $ri['urls'][] = $this->uurl_p . $Nz02tBCJvhpfbC8v; $ri['filenum']++; $ri['pf'] = $this->cpSyNl7FawzpxA['fopen'](TuLXmMBFSKj5mt.$Nz02tBCJvhpfbC8v,'w'); if(!$ri['pf']) $cYlf2voD22[] = TuLXmMBFSKj5mt.$Nz02tBCJvhpfbC8v; $this->RqZlVGtUBtP_7ir($ri['pf'], $L09ejYxM52UFE); } } return $l; } function U7eZgid0qLlTc4EeUU($Z9FJippp4759IlO, $CXZAq6Ajr6tIFa2, $L09ejYxM52UFE) { $Z9FJippp4759IlO['TYPE'.$L09ejYxM52UFE] = true; $ri = &$this->xEqv4Uo2Vlh[$L09ejYxM52UFE]; if($ri['pf']) { $_xu = $this->PpjB2YvxAtln6fZzm->Kfj_oHVF8EyzRFvRL($CXZAq6Ajr6tIFa2, $Z9FJippp4759IlO); $ri['xchs'] += strlen($_xu); $ri['xn']++; $ri['xnp']++; $this->cpSyNl7FawzpxA['fwrite']($ri['pf'], $_xu); } }  function vxT8Znbt67tVtRBn() { foreach($this->xEqv4Uo2Vlh as $L09ejYxM52UFE=>$ri) { $this->SBhmAIU6B6xgUtdc($ri['pf']); } } function d7mQcjzdu_8mWfl11() { foreach($this->R_Aw0OSpKh as $L09ejYxM52UFE=>$iJr01913iWk) { $ri = &$this->xEqv4Uo2Vlh[$L09ejYxM52UFE]; if(count($ri['urls'])>1) { $xf = $this->kp5kRAC7UiI5p($ri['urls']); array_unshift($ri['urls'],  $this->uurl_p.tRsLQ5oUyNb5($ri['sitemap_file'], $xf, TuLXmMBFSKj5mt, ($this->ybU_ViMnsXh['xs_compress']==1)) ); } $this->v70BS5IEjKUP76o($ri['sitemap_file']); } } function JymS3Pro0oyZpR($pWkVc4LlkYcoG71 = false) { if(($this->rDZaEE8hBFr + 30) < time() || $pWkVc4LlkYcoG71) { tRsLQ5oUyNb5('apicache.db',serialize($this->sfUCFCD4gz2),TuLXmMBFSKj5mt,true); $this->rDZaEE8hBFr = time(); } } function Qe1IXDUMeQ_h7ky0Iu0($vDt2ptm4Fr, $S1gHPAtxWg3rK = false, $zDYF7_FyUcAJgyGr = '') { global $BMbehimV7yzhTAnB; $Z6FvmduNR74l = $vDt2ptm4Fr . ($zDYF7_FyUcAJgyGr?'-'.md5($zDYF7_FyUcAJgyGr):''); Y1qFyrFH0Wg53("\nVideo api: $Z6FvmduNR74l , ".($this->sfUCFCD4gz2[$Z6FvmduNR74l]?'Cached':'Not in cache').", ".$this->sfUCFCD4gz2[$Z6FvmduNR74l]['code']); if(!isset($this->sfUCFCD4gz2[$Z6FvmduNR74l]) || !$this->sfUCFCD4gz2[$Z6FvmduNR74l] ||  (strstr($this->sfUCFCD4gz2[$Z6FvmduNR74l]['code'],'403') && !preg_match('#(private|authenticat|authorization|invalid)#si',$this->sfUCFCD4gz2[$Z6FvmduNR74l]['content']) ) ){ $_tr=4; while($_tr>0){ $fd = $BMbehimV7yzhTAnB->fetch($vDt2ptm4Fr, 0,true, false, '',  array('skipip' => true,'anytype'=>true,'addheaders'=>$zDYF7_FyUcAJgyGr)); $_tr--; if(strstr($fd['code'],'200'))$_tr=0; else sleep(3); } $this->sfUCFCD4gz2[$Z6FvmduNR74l] = $fd; $this->JymS3Pro0oyZpR(); } $eJm473_iCy0 = $this->sfUCFCD4gz2[$Z6FvmduNR74l]; if($S1gHPAtxWg3rK && $eJm473_iCy0 && function_exists('json_decode'))  { $eJm473_iCy0 ['decont'] = json_decode($eJm473_iCy0['content'], 1); } return $eJm473_iCy0; } function A8nL2VEUJaQD5Yq($kLp8rrLzV8fZgo7JFS) { $xz = 'video'; $MpCH90jT2UYn = array(); if(substr($kLp8rrLzV8fZgo7JFS['playerloc'],0,2)=='//')
																													 $kLp8rrLzV8fZgo7JFS['playerloc'] = 'http:'.$kLp8rrLzV8fZgo7JFS['playerloc']; if(preg_match('#youtube(-nocookie)?\.com|youtu\.be#', $kLp8rrLzV8fZgo7JFS['playerloc'])) { $kLp8rrLzV8fZgo7JFS['thumb']='https://i.ytimg.com/vi/'.$kLp8rrLzV8fZgo7JFS['vid'].'/2.jpg';
																													 } if(function_exists('xml_extra_video_step2'))xml_extra_video_step2($kLp8rrLzV8fZgo7JFS, $this->ybU_ViMnsXh); if($this->ybU_ViMnsXh['xs_video_extract']||!isset($this->ybU_ViMnsXh['xs_video_extract'])) { if(strstr($kLp8rrLzV8fZgo7JFS['playerloc'],'mtv.com')) { $QlDIrjacod6EI = $this->Qe1IXDUMeQ_h7ky0Iu0('http://www.mtv.com/player/embed/AS3/configuration.jhtml?vid='.$kLp8rrLzV8fZgo7JFS['vid']);
																													 if(preg_match('#(<feed>.*?</feed>)#is', $QlDIrjacod6EI['content'], $fm)) $QlDIrjacod6EI['content'] = $fm[1]; if(preg_match('#<media\:thumbnail url="(.*?)"#', $QlDIrjacod6EI['content'], $fm)) $kLp8rrLzV8fZgo7JFS['thumb'] = $fm[1]; if(preg_match('#duration="(\d+?)"#', $QlDIrjacod6EI['content'], $fm)) $kLp8rrLzV8fZgo7JFS['dur'] = $fm[1]; if(preg_match('#<pubDate>(.+?)<#', $QlDIrjacod6EI['content'], $fm)) $kLp8rrLzV8fZgo7JFS['pubdate'] = date('Y-m-d\TH:i:s+00:00',strtotime($fm[1])); if(preg_match('#<title>(.+?)<#', $QlDIrjacod6EI['content'], $fm)) $kLp8rrLzV8fZgo7JFS['title'] = $fm[1]; if(preg_match('#<description>(.*?)<#', $QlDIrjacod6EI['content'], $fm)) $kLp8rrLzV8fZgo7JFS['desc'] = $fm[1]; if(preg_match('#<media:player url="(.+?)"#', $QlDIrjacod6EI['content'], $fm)) $kLp8rrLzV8fZgo7JFS['playerloc'] = $fm[1]; }   if(preg_match('#youtube(-nocookie)?\.com|youtu\.be#', $kLp8rrLzV8fZgo7JFS['playerloc'])) { if(($weCrXTdHIIePk = $this->ybU_ViMnsXh['xs_youtube_api_key']) && function_exists('json_decode')) { $vO5Q3kee_ROb = 'https://www.googleapis.com/youtube/v3/';
																													 $FNJ7xKLHPyX4Nzh7M = '&key='.$weCrXTdHIIePk; $WMoWXYkoERo48e = $vO5Q3kee_ROb .'videos?part=snippet,contentDetails'.$FNJ7xKLHPyX4Nzh7M.'&id='; $pPZPBNFaOen9ywI_MD = $vO5Q3kee_ROb .'playlistItems?part=contentDetails'.$FNJ7xKLHPyX4Nzh7M.'&playlistId='; if(preg_match('#list=([a-z0-9\-\_]+)#i', $kLp8rrLzV8fZgo7JFS['extra'], $lm)){ $QlDIrjacod6EI = $this->Qe1IXDUMeQ_h7ky0Iu0($pPZPBNFaOen9ywI_MD.$lm[1], true); }else { $QlDIrjacod6EI = $this->Qe1IXDUMeQ_h7ky0Iu0($WMoWXYkoERo48e.$kLp8rrLzV8fZgo7JFS['vid'], true); } if($jl = $QlDIrjacod6EI['decont']) $mrSurWahf = $jl['items']; foreach($mrSurWahf as $M8r3sNb8Br6fwU3Lb) { $cd = $M8r3sNb8Br6fwU3Lb['contentDetails']; if($cd && ($XgQz3vq7L4s357ryV = $cd['videoId'])) { $QlDIrjacod6EI = $this->Qe1IXDUMeQ_h7ky0Iu0($WMoWXYkoERo48e.$XgQz3vq7L4s357ryV, 1); if($QlDIrjacod6EI['decont']){ $M8r3sNb8Br6fwU3Lb = $QlDIrjacod6EI['decont']['items'][0]; $cd = $M8r3sNb8Br6fwU3Lb['contentDetails']; }else  continue; } $jc = $P8CS7foVvNfYzV_f = $M8r3sNb8Br6fwU3Lb; $fu73cPFCzK = $kLp8rrLzV8fZgo7JFS; if($cd) { if(preg_match('#(?:(\d+)H)?(\d+)M(\d+)S#i', $cd['duration'], $NRxt8dPGm)) $fu73cPFCzK['dur'] = ($NRxt8dPGm[1]*60 + $NRxt8dPGm[2]) * 60 + $NRxt8dPGm[3]; } if($sn = $P8CS7foVvNfYzV_f['snippet']){ $fu73cPFCzK['thumb'] = $sn['thumbnails']['medium']['url']; $fu73cPFCzK['pubdate'] = $sn['publishedAt']; $fu73cPFCzK['title'] = $this->O7C3vS0c0YUBBdY($sn['title']); $fu73cPFCzK['desc'] = $this->O7C3vS0c0YUBBdY($sn['description']); } if($id = $P8CS7foVvNfYzV_f['id']){ $fu73cPFCzK['vid'] = $id; $fu73cPFCzK['playerloc'] = 'http://www.youtube.com/v/'.$id;
																													 } $MpCH90jT2UYn[] = $fu73cPFCzK; } } } if(strstr($kLp8rrLzV8fZgo7JFS['playerloc'],'video.google.com')) { $QlDIrjacod6EI = $this->Qe1IXDUMeQ_h7ky0Iu0('http://video.google.com/videofeed?docid='.$kLp8rrLzV8fZgo7JFS['vid']);
																													 if(preg_match('#<media\:thumbnail url="(.*?)"#', $QlDIrjacod6EI['content'], $fm)) $kLp8rrLzV8fZgo7JFS['thumb'] = $fm[1]; if(preg_match('#duration="(\d+?)"#', $QlDIrjacod6EI['content'], $fm)) $kLp8rrLzV8fZgo7JFS['dur'] = $fm[1]; if(preg_match('#<pubDate>(.+?)<#', $QlDIrjacod6EI['content'], $fm)) $kLp8rrLzV8fZgo7JFS['pubdate'] = date('Y-m-d\TH:i:s+00:00',strtotime($fm[1])); if(preg_match('#<title>(.+?)<#is', $QlDIrjacod6EI['content'], $fm)) $kLp8rrLzV8fZgo7JFS['title'] = $fm[1]; if(preg_match('#<description>(.*?)<#is', $QlDIrjacod6EI['content'], $fm)) $kLp8rrLzV8fZgo7JFS['desc'] = $fm[1]; } if(strstr($kLp8rrLzV8fZgo7JFS['playerloc'],'vimeo.com'))		 if($this->ybU_ViMnsXh['xs_vimeo_api_token']) {   $QlDIrjacod6EI = $this->Qe1IXDUMeQ_h7ky0Iu0($q='http://vimeo.com/api/v2/video/'.$kLp8rrLzV8fZgo7JFS['vid'].'.xml');
																													 $kLp8rrLzV8fZgo7JFS['playerloc'] = 'http://www.vimeo.com/moogaloop.swf?clip_id='.$kLp8rrLzV8fZgo7JFS['vid'];
																													 if(preg_match('#<thumbnail_medium>(.*?)<#', $QlDIrjacod6EI['content'], $fm)) $kLp8rrLzV8fZgo7JFS['thumb'] = $fm[1]; if(preg_match('#<duration>(\d+)#', $QlDIrjacod6EI['content'], $fm)) $kLp8rrLzV8fZgo7JFS['dur'] = $fm[1]; if(preg_match('#<upload_date>(.+?)<#', $QlDIrjacod6EI['content'], $fm)) $kLp8rrLzV8fZgo7JFS['pubdate'] = date('Y-m-d\TH:i:s+00:00',strtotime($fm[1])); if(preg_match('#<title>(.+?)<#is', $QlDIrjacod6EI['content'], $fm)) $kLp8rrLzV8fZgo7JFS['title'] = $fm[1]; if(preg_match('#<description>(.*?)<#is', $QlDIrjacod6EI['content'], $fm)) $kLp8rrLzV8fZgo7JFS['desc'] = $fm[1]; } if(strstr($kLp8rrLzV8fZgo7JFS['playerloc'],'blip.tv')) { $QlDIrjacod6EI = $this->Qe1IXDUMeQ_h7ky0Iu0($q='http://blip.tv/players/episode/'.$kLp8rrLzV8fZgo7JFS['vid'].'?skin=rss');
																													 if( preg_match('#<blip:smallThumbnail>(.*?)<#', $QlDIrjacod6EI['content'], $fm)|| preg_match('#<media\:thumbnail url="(.*?)"#', $QlDIrjacod6EI['content'], $fm)|| preg_match('#<blip:picture>(.*?)<#', $QlDIrjacod6EI['content'], $fm) ) $kLp8rrLzV8fZgo7JFS['thumb'] = $fm[1]; if(preg_match('#<blip:runtime>(\d+)#', $QlDIrjacod6EI['content'], $fm)) $kLp8rrLzV8fZgo7JFS['dur'] = $fm[1]; if(preg_match('#<blip:datestamp>(.+?)<#', $QlDIrjacod6EI['content'], $fm)) $kLp8rrLzV8fZgo7JFS['pubdate'] = date('Y-m-d\TH:i:s+00:00',strtotime($fm[1])); if(preg_match('#<item>.*?<title>(.*?)<#is', $QlDIrjacod6EI['content'], $fm)) $kLp8rrLzV8fZgo7JFS['title'] = $fm[1]; if(preg_match('#<item>.*?<description>(?:<!\[CDATA\[)?(.+?)(?:\]\]>)?</description>#is', $QlDIrjacod6EI['content'], $fm)){ $kLp8rrLzV8fZgo7JFS['desc'] = trim(strip_tags($fm[1])); } } if(strstr($kLp8rrLzV8fZgo7JFS['playerloc'],'dailymotion.com')) { $QlDIrjacod6EI = $this->Qe1IXDUMeQ_h7ky0Iu0($q='https://api.dailymotion.com/video/'.$kLp8rrLzV8fZgo7JFS['vid'].'?fields=title,url,thumbnail_medium_url,tags,published,created_time,description,duration');
																													 $df = @json_decode(($QlDIrjacod6EI['content']),1); if($_tt = $df['thumbnail_medium_url']) $kLp8rrLzV8fZgo7JFS['thumb'] = $_tt; if($_tt = $df['duration']) $kLp8rrLzV8fZgo7JFS['dur'] = $_tt; if($_tt = $df['created_time']) $kLp8rrLzV8fZgo7JFS['pubdate'] = date('Y-m-d\TH:i:s+00:00',$_tt); if($_tt = $df['title']) $kLp8rrLzV8fZgo7JFS['title'] = $this->O7C3vS0c0YUBBdY($_tt, true, true); if($_tt = $df['description']) $kLp8rrLzV8fZgo7JFS['desc'] = $this->O7C3vS0c0YUBBdY($_tt, true, true);   } if(strstr($kLp8rrLzV8fZgo7JFS['playerloc'],'coull.com')) { $QlDIrjacod6EI = $this->Qe1IXDUMeQ_h7ky0Iu0($q='http://network.coull.com/api/open/getvideobyid?id='.$kLp8rrLzV8fZgo7JFS['vid']);
																													 if(preg_match('#<image_url>(.*?)<#', $QlDIrjacod6EI['content'], $fm)) $kLp8rrLzV8fZgo7JFS['thumb'] = $fm[1]; if(preg_match('#<duration>(\d+)#', $QlDIrjacod6EI['content'], $fm)) $kLp8rrLzV8fZgo7JFS['dur'] = $fm[1]; if(preg_match('#<created>(.+?)<#', $QlDIrjacod6EI['content'], $fm)) $kLp8rrLzV8fZgo7JFS['pubdate'] = date('Y-m-d\TH:i:s+00:00',strtotime($fm[1])); if(preg_match('#<title>(.+?)<#is', $QlDIrjacod6EI['content'], $fm)) $kLp8rrLzV8fZgo7JFS['title'] = $fm[1]; if(preg_match('#<description>(.*?)<#is', $QlDIrjacod6EI['content'], $fm)) $kLp8rrLzV8fZgo7JFS['desc'] = $fm[1]; } } if(!$MpCH90jT2UYn)$MpCH90jT2UYn[] = $kLp8rrLzV8fZgo7JFS; $xz = '/video'; return $MpCH90jT2UYn; } function nIUCo1zLYAeyVV($urls_completed, &$rnyRt410SGvdObwSv_w) { global $CXZAq6Ajr6tIFa2, $nU81VdneUkZSVv1KQo9, $LTQF0KwWL6IUj27G, $sm_proc_list, $If066XdyD8Kf, $YH5ByymgQ21cHm, $cYlf2voD22; $cKosV6oybpxy = $this->ybU_ViMnsXh['xs_chlog']; $DVPCEWXKsVB6s9Hi = ciWGCr0W_(anC6EcMhf2cAQc,  'sitemap_xml_tpl.xml'); $fWkV_ZNLjOr2_Y = file_get_contents(anC6EcMhf2cAQc.$DVPCEWXKsVB6s9Hi); preg_match('#^(.*)%URLS_LIST_FROM%(.*)%URLS_LIST_TO%(.*)$#is', $fWkV_ZNLjOr2_Y, $CXZAq6Ajr6tIFa2); $CXZAq6Ajr6tIFa2[1] = str_replace('www.xml-sitemaps.com', 'www.xml-sitemaps.com ('. sAI0XfHZxrZ2WX.')', $CXZAq6Ajr6tIFa2[1]); $CXZAq6Ajr6tIFa2[1] = str_replace('%GEN_URL%', $this->ybU_ViMnsXh['gendom'], $CXZAq6Ajr6tIFa2[1]); $QZJVFcZ6re4FoVX = preg_replace('#[^\\/]+?\.xml$#', '', $this->ybU_ViMnsXh['xs_smurl']); $CXZAq6Ajr6tIFa2[1] = str_replace('%SM_BASE%', $QZJVFcZ6re4FoVX, $CXZAq6Ajr6tIFa2[1]); if($this->ybU_ViMnsXh['xs_disable_xsl']) $CXZAq6Ajr6tIFa2[1] = preg_replace('#<\?xml-stylesheet.*\?>#', '', $CXZAq6Ajr6tIFa2[1]);
																													if($this->ybU_ViMnsXh['xs_nobrand']){
																													$CXZAq6Ajr6tIFa2[1] = str_replace('sitemap.xsl','sitemap_nb.xsl',$CXZAq6Ajr6tIFa2[1]);
																													$CXZAq6Ajr6tIFa2[1] = preg_replace('#<!-- created.*?>#','',$CXZAq6Ajr6tIFa2[1]);
																													}
																													$Pk45sxBaXQmkp = implode('', file(anC6EcMhf2cAQc.'sitemap_ror_tpl.xml'));
																													preg_match('#^(.*)%URLS_LIST_FROM%(.*)%URLS_LIST_TO%(.*)$#is', $Pk45sxBaXQmkp, $nU81VdneUkZSVv1KQo9);
																													$EqFKbP8k2jss = implode('', file(anC6EcMhf2cAQc.'sitemap_rss_tpl.xml'));
																													preg_match('#^(.*)%URLS_LIST_FROM%(.*)%URLS_LIST_TO%(.*)$#is', $EqFKbP8k2jss, $GQp5r1qTRTjF1SK4);
																													$K2W9jdorBId9ch = implode('', file(anC6EcMhf2cAQc.'sitemap_base_tpl.xml'));
																													preg_match('#^(.*)%URLS_LIST_FROM%(.*)%URLS_LIST_TO%(.*)$#is', $K2W9jdorBId9ch, $LTQF0KwWL6IUj27G);
																													$this->T0ExLFU3uN = $this->ybU_ViMnsXh['xs_sm_size']?$this->ybU_ViMnsXh['xs_sm_size']:50000;
																													$this->sm_filesplit = $this->ybU_ViMnsXh['xs_sm_filesize']?$this->ybU_ViMnsXh['xs_sm_filesize']:10;
																													$this->sm_filesplit = max(intval($this->sm_filesplit*1024*1024),2000)-1000;
																													if(isset($this->ybU_ViMnsXh['xs_webinfo']) && !$this->ybU_ViMnsXh['xs_webinfo'])
																													unset($this->R_Aw0OSpKh[0]);
																													if(!$this->ybU_ViMnsXh['xs_imginfo'])
																													unset($this->R_Aw0OSpKh[1]);
																													if(!$this->ybU_ViMnsXh['xs_videoinfo'])
																													unset($this->R_Aw0OSpKh[2]);
																													if(!$this->ybU_ViMnsXh['xs_newsinfo'])
																													unset($this->R_Aw0OSpKh[3]);
																													if(!$this->ybU_ViMnsXh['xs_makemob'])
																													unset($this->R_Aw0OSpKh[4]);
																													if(!$this->ybU_ViMnsXh['xs_rssinfo'])
																													unset($this->R_Aw0OSpKh[5]);
																													$_alang = preg_split('#[\r\n]+#', $this->ybU_ViMnsXh['xs_alt_lang']);
																													$_acur = '';
																													$_at = '';
																													$this->H5M0t7u_oDB6SFwE0vN = array('s' => array(), 'r' => array());
																													foreach($_alang as $v){
																													$me = explode(' ', $v);
																													if($me[1]) {
																													$this->H5M0t7u_oDB6SFwE0vN[$_at][$_acur][] = array('t' => 'hreflang', 'l' => $me[0], 'u' => $me[1]);
																													}else {
																													$_at = strstr($v,'*') ? 'r' : 's';
																													$_acur = $v;
																													$this->H5M0t7u_oDB6SFwE0vN[$_at][$_acur] = array();
																													}
																													}
																													$ctime = date('Y-m-d H:i:s');
																													$tVEUru6x7 = 0;
																													global $mURYMUthN5Q_d4;
																													$tt = array('<','>');
																													foreach ($tt as $Opgvomhpbz7YPfY9 )
																													$mURYMUthN5Q_d4[$Opgvomhpbz7YPfY9] = '&#'.ord($Opgvomhpbz7YPfY9).';';
																													for($i=0;$i<31;$i++)
																													$mURYMUthN5Q_d4[chr($i)] = '';
																													
																													$mURYMUthN5Q_d4[chr(0)] = $mURYMUthN5Q_d4[chr(10)] = $mURYMUthN5Q_d4[chr(13)] = '';
																													$mURYMUthN5Q_d4[' '] = '%20';
																													$pf = 0;
																													
																													$cfIevcU1tyOvSZDI = intval($If066XdyD8Kf['istart']);
																													$this->nhJxcLjMzdOireWhGRW($If066XdyD8Kf);
																													if($this->ybU_ViMnsXh['xs_maketxt'])
																													{
																													$ukdmIj7HhpSk6d = $this->cpSyNl7FawzpxA['fopen'](icByz5QY6DzKNenF.$this->R835G5lbvW9JfMRYGV, $cfIevcU1tyOvSZDI?'a':'w');
																													if(!$ukdmIj7HhpSk6d)$cYlf2voD22[] = icByz5QY6DzKNenF.$this->R835G5lbvW9JfMRYGV;
																													}
																													if($this->ybU_ViMnsXh['xs_makeror'])
																													{
																													$oaShQu6EvbenA = cokTfdpvPOceFs7s(y9YizbQlJl, $cfIevcU1tyOvSZDI?'a':'w');
																													$rc = str_replace('%INIT_URL%', $this->ybU_ViMnsXh['xs_initurl'], $nU81VdneUkZSVv1KQo9[1]);
																													if($oaShQu6EvbenA)
																													SEQKcL37vrK0KML0($oaShQu6EvbenA, $rc);
																													else
																													$cYlf2voD22[] = y9YizbQlJl;
																													}
																													if($this->ybU_ViMnsXh['xs_rssinfo'])
																													{
																													$EFHJlZzgT3cKz50td = $this->uurl_p . basename(OTtVIJkRdICOMwu);
																													$YtKWh65IT0 = OTtVIJkRdICOMwu;
																													$CEXEvCI1xRE = cokTfdpvPOceFs7s($YtKWh65IT0, $cfIevcU1tyOvSZDI?'a':'w');
																													$rc = str_replace('%INIT_URL%', $this->ybU_ViMnsXh['xs_initurl'], $GQp5r1qTRTjF1SK4[1]);
																													$rc = str_replace('%FEED_TITLE%', $this->ybU_ViMnsXh['xs_rsstitle'], $rc);
																													$rc = str_replace('%BUILD_DATE%', gmdate('D, d M Y H:i:s +0000'), $rc);
																													$rc = str_replace('%SELF_URL%', $EFHJlZzgT3cKz50td, $rc);
																													if($CEXEvCI1xRE)
																													SEQKcL37vrK0KML0($CEXEvCI1xRE, $rc);
																													else
																													$cYlf2voD22[] = $YtKWh65IT0;
																													}
																													if($sm_proc_list)
																													foreach($sm_proc_list as $k=>$woHZoRlCs3vHhxnT9)
																													$sm_proc_list[$k]->n6exfGEH4FqCO($this->ybU_ViMnsXh, $this->cpSyNl7FawzpxA, $this->PpjB2YvxAtln6fZzm);
																													if($this->ybU_ViMnsXh['xs_write_delay'])
																													list($eLMQZW6Ud, $EIuAUbHppEexXPDAN) = explode('|',$this->ybU_ViMnsXh['xs_write_delay']);
																													for($i=$xn=$cfIevcU1tyOvSZDI;$i<count($urls_completed);$i++,$xn++)
																													{   
																													
																													
																													
																													if($i%100 == 0) {
																													oE9dBNjn0hHPEIxcl();
																													global $AytXoOMaBW5POdJt1;$AytXoOMaBW5POdJt1->J1aZ1U_EhNDVvG(array('smcreate'=>array('xml',$i,count($urls_completed))));
																													Y1qFyrFH0Wg53(" / $i / ".(time()-$_tm));
																													$_tm=time();
																													}
																													d82oX1fkf(array(
																													'cmd'=> 'info',
																													'id' => 'percprog',
																													'text'=> number_format($i*100/count($urls_completed),0).'%'
																													));
																													$jp2kmbs_Fb = $this->Z3hA8JJa59fdvUSi();
																													if($jp2kmbs_Fb && ($i != $cfIevcU1tyOvSZDI))
																													{
																													tRsLQ5oUyNb5($YH5ByymgQ21cHm,AEks4EOfaorM1XL(array('istart'=>$i,'rinfo'=>$this->xEqv4Uo2Vlh)));
																													}
																													if($this->ybU_ViMnsXh['xs_memsave'])
																													{
																													$cu = jc8PTlfERBm6($urls_completed[$i]);
																													}else
																													$cu = $urls_completed[$i];
																													if(!is_array($cu)) $cu = @unserialize($cu);
																													$l = $this->E2SNQCVgf3A6FI($cu['link']);
																													$cu['link'] = $l;
																													$t = $this->O7C3vS0c0YUBBdY($cu['t'], true, true);
																													$d = $this->O7C3vS0c0YUBBdY($cu['d'] ? $cu['d'] : $cu['t'], true, true);
																													$t2 = $this->O7C3vS0c0YUBBdY($cu['t'], false);
																													$d2 = $this->O7C3vS0c0YUBBdY($cu['d']?$cu['d']:$cu['t'], false);
																													$EUUrMs386 = '';
																													if($cu['clm'] && ($uAsGMnOghv_A2mp_oh = preg_replace('#\s+[a-z]+$#is', '', $cu['clm'])) && strtotime($uAsGMnOghv_A2mp_oh))
																													$EUUrMs386 = $uAsGMnOghv_A2mp_oh;
																													else
																													switch($this->ybU_ViMnsXh['xs_lastmod']){
																													case 1:$EUUrMs386 = $cu['lm']?$cu['lm']:$ctime;break;
																													case 2:$EUUrMs386 = $ctime;break;
																													case 3:$EUUrMs386 = $this->ybU_ViMnsXh['xs_lastmodtime'];break;
																													}
																													$oyKROh9fnQ_mZC = $WlYT7mk6tGIvoCTzYE5 = false;
																													if($cu['p'])
																													$p = $cu['p'];
																													else
																													{
																													$p = floatval($this->ybU_ViMnsXh['xs_priority']);
																													if($this->ybU_ViMnsXh['xs_autopriority'])
																													{
																													$p = $p*pow($this->ybU_ViMnsXh['xs_descpriority']?$this->ybU_ViMnsXh['xs_descpriority']:0.8,intval($cu['o']));
																													if($this->IHiOrtRzo3G)
																													{
																													$oyKROh9fnQ_mZC = true;
																													$WlYT7mk6tGIvoCTzYE5 = ($this->IHiOrtRzo3G&&!isset($this->IHiOrtRzo3G[$cu['link']]))||$this->LsF8VuWqrbnnrI7N2[$cu['link']];
																													if($WlYT7mk6tGIvoCTzYE5)
																													$p=0.95;
																													}
																													$p = max(0.0001,min($p,1.0));
																													$p = @number_format($p, 4);
																													}
																													}
																													if($EUUrMs386){
																													$EUUrMs386 = strtotime($EUUrMs386);
																													$EUUrMs386 = gmdate('Y-m-d\TH:i:s+00:00',$EUUrMs386);
																													}
																													$f = $cu['f']?$cu['f']:$this->ybU_ViMnsXh['xs_freq'];
																													$_al = array();
																													if($this->H5M0t7u_oDB6SFwE0vN['s'][$l])
																													$_al = $this->H5M0t7u_oDB6SFwE0vN['s'][$l];
																													else
																													{
																													foreach($this->H5M0t7u_oDB6SFwE0vN['r'] as $_aurl => $_ll)
																													if(preg_match('#'.$_aurl.'#i', $l, $lm)) {
																													$_al = $_ll;
																													foreach($_al as $_k=>$_v)
																													$_al[$_k]['u'] = $this->E2SNQCVgf3A6FI(preg_replace('#'.$_aurl.'#', $_v['u'], $l));
																													break;
																													}
																													}
																													if(!$_al)
																													$_al = $cu['hl'];
																													if($_al)
																													foreach($_al as $_k=>$_v)
																													$_al[$_k]['u'] = $this->E2SNQCVgf3A6FI($_v['u']);
																													$Z9FJippp4759IlO = array(
																													'URL'=>$l,
																													'TITLE'=>$t,
																													'DESC'=>($d),
																													'PERIOD'=>$f,
																													'LASTMOD'=>$EUUrMs386,
																													'ORDER'=>$cu['o'],
																													'PRIORITY'=>$p,
																													'ALTLANG' => $_al
																													);
																													if($this->ybU_ViMnsXh['xs_makemob'])
																													{
																													if(!$this->ybU_ViMnsXh['xs_mobileincmask'] ||
																													preg_match('#'.str_replace(' ', '|', preg_quote($this->ybU_ViMnsXh['xs_mobileincmask'],'#')).'#',$Z9FJippp4759IlO['URL']))
																													$this->U7eZgid0qLlTc4EeUU(array_merge($Z9FJippp4759IlO, array('ismob'=>true)), $CXZAq6Ajr6tIFa2[2], 4);
																													}
																													$xz = 'news';
																													if($this->ybU_ViMnsXh['xs_newsinfo'])
																													if(!$this->ybU_ViMnsXh['xs_newsinfo_max'] ||
																													($this->newsno < $this->ybU_ViMnsXh['xs_newsinfo_max']))
																													{
																													if(!$oyKROh9fnQ_mZC)
																													$WlYT7mk6tGIvoCTzYE5 = ($this->IHiOrtRzo3G&&!isset($this->IHiOrtRzo3G[$cu['link']]))||$this->LsF8VuWqrbnnrI7N2[$cu['link']];
																													if($this->ybU_ViMnsXh['xs_newsincmask'])
																													if(!preg_match('#'.str_replace(' ', '|', preg_quote($this->ybU_ViMnsXh['xs_newsincmask'],'#')).'#',$cu['link']))
																													$WlYT7mk6tGIvoCTzYE5 = false;
																													if($WlYT7mk6tGIvoCTzYE5)
																													{
																													$s3lhOklOjG = $this->LsF8VuWqrbnnrI7N2[$cu['link']] ? $this->LsF8VuWqrbnnrI7N2[$cu['link']] : 
																													date('Y-m-d');
																													$this->newsno++;
																													$this->U7eZgid0qLlTc4EeUU(array(
																													'URL'=>$l,
																													'TITLE'=>$t,
																													'LASTMOD'=>$s3lhOklOjG.'T00:00:00+00:00',
																													'N_NAME'=>$this->ybU_ViMnsXh['xs_newstitle'],
																													'N_LANG'=>$this->ybU_ViMnsXh['xs_newslang'],
																													'N_DATE'=>$s3lhOklOjG
																													), $CXZAq6Ajr6tIFa2[2], 3);
																													}
																													}
																													$xz = '/news';
																													$xz = 'rss';
																													if($this->ybU_ViMnsXh['xs_rssinfo'])
																													if(!$this->ybU_ViMnsXh['xs_rssinfo_max'] ||
																													($this->rssno < $this->ybU_ViMnsXh['xs_rssinfo_max']))
																													{
																													$GFYUbLlXNffta = ($this->IHiOrtRzo3G&&!isset($this->IHiOrtRzo3G[$cu['link']]))
																													|| $this->urls_prevrss[$cu['link']]
																													|| !$this->ybU_ViMnsXh['xs_rssage'];
																													if($this->ybU_ViMnsXh['xs_rssincmask'])
																													if(!preg_match('#'.str_replace(' ', '|', preg_quote($this->ybU_ViMnsXh['xs_rssincmask'],'#')).'#',$cu['link']))
																													$GFYUbLlXNffta = false;
																													if($GFYUbLlXNffta)
																													{
																													$s3lhOklOjG = $this->urls_prevrss[$cu['link']] ? strtotime($this->urls_prevrss[$cu['link']]) : time();
																													$s3lhOklOjG = gmdate('D, d M Y H:i:s +0000', $s3lhOklOjG);
																													$this->rssno++;
																													SEQKcL37vrK0KML0($CEXEvCI1xRE, 
																													$this->PpjB2YvxAtln6fZzm->Kfj_oHVF8EyzRFvRL($GQp5r1qTRTjF1SK4[2],
																													array(
																													'URL'=>$l,
																													'GUID' => md5($l),
																													'TITLE'=>$t2,
																													'DESC'=>$d2,
																													
																													
																													'LASTMOD'=>$s3lhOklOjG,
																													)));
																													}
																													}
																													$xz = '/rss';
																													$this->U7eZgid0qLlTc4EeUU($Z9FJippp4759IlO, $CXZAq6Ajr6tIFa2[2], 0);
																													$xz = 'img';
																													$_ni = array();
																													$_pi = $this->EN9d8roOb9i4FFtntXC[$cu['link']];
																													if(!$_pi)$_pi = array();
																													
																													if($cu['i'])
																													{
																													foreach($cu['i'] as $im){
																													$_ci = array(
																													'iurl'=>$this->E2SNQCVgf3A6FI($im[0]), 
																													
																													'caption'=>$this->O7C3vS0c0YUBBdY($im[1])
																													);
																													$Z9FJippp4759IlO['imgs'][] = $_ci;
																													if($cKosV6oybpxy) 
																													{
																													if(! $_pi[$_ci['iurl']] )
																													{
																													if(count($this->uiX3GL_J7HZc)<$this->mYc_4ih7eCuVr6)
																													$_ni[$_ci['iurl']]++;
																													}
																													else 
																													if($_pi)
																													unset($_pi[$_ci['iurl']]);
																													}
																													}
																													
																													if($_ni)
																													$this->uiX3GL_J7HZc[$cu['link']] = $_ni;
																													if(!$_pi)
																													unset($this->EN9d8roOb9i4FFtntXC[$cu['link']]);
																													else
																													$this->EN9d8roOb9i4FFtntXC[$cu['link']] = $_pi;
																													if($Z9FJippp4759IlO['imgs'])
																													{
																													$this->imgno+=count($Z9FJippp4759IlO['imgs']);
																													$this->U7eZgid0qLlTc4EeUU($Z9FJippp4759IlO, $CXZAq6Ajr6tIFa2[2], 1);
																													}
																													unset($Z9FJippp4759IlO['imgs']);
																													}
																													$xz = '/img';
																													$xz = 'video';
																													$_ni = array();
																													$_pi = $this->svw3REUlYzWcCmRHXFg[$cu['link']];
																													if(!$_pi)$_pi = array();
																													if($cu['v'])
																													{
																													foreach($cu['v'] as $im)
																													{
																													if($im['thumb']) {
																													$im['playerloc'] = $this->E2SNQCVgf3A6FI($im['playerloc']);
																													$im['desc'] = $this->SB3Mx0FN6T1phEFI9F($im['desc']);
																													$im['title'] = $this->SB3Mx0FN6T1phEFI9F($im['title']);
																													$im['thumb'] = $this->E2SNQCVgf3A6FI($im['thumb']);
																													$Z9FJippp4759IlO['videos'][] = $im;
																													}else {
																													$MpCH90jT2UYn = $this->A8nL2VEUJaQD5Yq(array(
																													'vid' => $im[1],
																													'extra' => $im[2],
																													'title'=>$this->O7C3vS0c0YUBBdY($t, true, true),
																													'desc'=>$this->O7C3vS0c0YUBBdY($d?$d:$t, true, true),
																													'playerloc'=>$im[0],
																													));
																													foreach($MpCH90jT2UYn as $k=>$xz){
																													if($im[3])$xz['title'] = $im[3];
																													if($im[4])$xz['desc'] = $im[4];
																													if($xz['thumb']){
																													if($im[5]){
																													$xz['thumb'] = $im[5];
																													}else 
																													if(!strstr($xz['thumb'], 'ytimg.com'))
																													{
																													preg_match('#\.(jpg|gif|png)#', $xz['thumb'], $em);
																													$nBB3KkBWp4DPEYweolj = md5($xz['thumb']).'.'.($em?$em[1]:'jpg');
																													$S0dV3wDfizCY9rpGF = ($this->ybU_ViMnsXh['xs_dat_url'] ? $this->ybU_ViMnsXh['xs_dat_url'] : $this->ybU_ViMnsXh['gendom'] . 'data/') . $nBB3KkBWp4DPEYweolj;
																													if(file_exists(TuLXmMBFSKj5mt . $nBB3KkBWp4DPEYweolj) && filesize(TuLXmMBFSKj5mt . $nBB3KkBWp4DPEYweolj)) {
																													touch(TuLXmMBFSKj5mt . $nBB3KkBWp4DPEYweolj);
																													}else {
																													global $BMbehimV7yzhTAnB;
																													$U4hhr_dHyjNDno64lo = $BMbehimV7yzhTAnB->fetch($xz['thumb'],0,true, false, '', array('skipip' => true,'anytype'=>true));
																													
																													tRsLQ5oUyNb5($nBB3KkBWp4DPEYweolj, $U4hhr_dHyjNDno64lo['content']);
																													}
																													$xz['thumb'] = $S0dV3wDfizCY9rpGF;
																													}
																													$Z9FJippp4759IlO['videos'][] = $xz;
																													}
																													}
																													}
																													}
																													if($Z9FJippp4759IlO['videos'])
																													{
																													foreach($Z9FJippp4759IlO['videos'] as $_ii=>$_ci){
																													if($_ci['dur'])
																													$Z9FJippp4759IlO['videos'][$_ii]['dur'] = min($_ci['dur'], 28800);
																													}
																													if($cKosV6oybpxy) 
																													{
																													foreach($Z9FJippp4759IlO['videos'] as $_ci)
																													{
																													if(! $_pi[$_ci['playerloc']] )
																													{
																													if(count($this->yfngMOg3hhWu)<$this->mYc_4ih7eCuVr6)
																													$_ni[$_ci['playerloc']]++;
																													}
																													else 
																													if($_pi)
																													unset($_pi[$_ci['playerloc']]);
																													}
																													}
																													$this->videos_no+=count($Z9FJippp4759IlO['videos']);
																													$this->U7eZgid0qLlTc4EeUU($Z9FJippp4759IlO, $CXZAq6Ajr6tIFa2[2], 2);
																													}
																													if($_ni)
																													$this->yfngMOg3hhWu[$cu['link']] = $_ni;
																													if(!$_pi)
																													unset($this->svw3REUlYzWcCmRHXFg[$cu['link']]);
																													else
																													$this->svw3REUlYzWcCmRHXFg[$cu['link']] = $_pi;
																													}
																													$xz = '/video';
																													if($this->ybU_ViMnsXh['xs_maketxt'] && $ukdmIj7HhpSk6d)
																													$this->cpSyNl7FawzpxA['fwrite']($ukdmIj7HhpSk6d, $cu['link']."\n");
																													if($sm_proc_list)
																													foreach($sm_proc_list as $woHZoRlCs3vHhxnT9)
																													$woHZoRlCs3vHhxnT9->DX9xNjozy17nwLs($Z9FJippp4759IlO);
																													if($this->ybU_ViMnsXh['xs_makeror'] && $oaShQu6EvbenA)
																													if(!$this->ybU_ViMnsXh['xs_ror_max'] ||
																													($i < $this->ybU_ViMnsXh['xs_ror_max']))
																													{
																													$tt = $t2;
																													$dd = $d2;
																													if($this->ybU_ViMnsXh['xs_ror_unique']){
																													while($X8JtNAylCZ=$ai[md5('t'.$tt)]++){
																													$tt=$Z9FJippp4759IlO['TITLE'].' '.$X8JtNAylCZ;
																													}
																													while($X8JtNAylCZ=$ai[md5('d'.$dd)]++){
																													$dd=$Z9FJippp4759IlO['DESC'].' '.$X8JtNAylCZ;
																													}
																													}
																													$Z9FJippp4759IlO['TITLE'] = $tt;
																													$Z9FJippp4759IlO['DESC'] = $dd;
																													SEQKcL37vrK0KML0($oaShQu6EvbenA, $this->PpjB2YvxAtln6fZzm->Kfj_oHVF8EyzRFvRL($nU81VdneUkZSVv1KQo9[2],$Z9FJippp4759IlO));
																													}
																													if($cKosV6oybpxy) {
																													if(!isset($this->IHiOrtRzo3G[$cu['link']]) && 
																													count($this->LPEvwRmovihMV)<$this->mYc_4ih7eCuVr6)
																													$this->LPEvwRmovihMV[$cu['link']]++;
																													}
																													unset($this->IHiOrtRzo3G[$cu['link']]);
																													}
																													$this->vxT8Znbt67tVtRBn();
																													if($this->ybU_ViMnsXh['xs_maketxt'])
																													{
																													$this->cpSyNl7FawzpxA['fclose']($ukdmIj7HhpSk6d);
																													@chmod(icByz5QY6DzKNenF.$this->R835G5lbvW9JfMRYGV, 0666);
																													}
																													if($this->ybU_ViMnsXh['xs_makeror'])
																													{
																													if($oaShQu6EvbenA)
																													SEQKcL37vrK0KML0($oaShQu6EvbenA, $nU81VdneUkZSVv1KQo9[3]);
																													fclose($oaShQu6EvbenA);
																													}
																													if($this->ybU_ViMnsXh['xs_rssinfo'])
																													{
																													if($CEXEvCI1xRE)
																													SEQKcL37vrK0KML0($CEXEvCI1xRE, $GQp5r1qTRTjF1SK4[3]);
																													fclose($CEXEvCI1xRE);
																													$this->v70BS5IEjKUP76o($this->ybU_ViMnsXh['xs_rssfilename']);
																													}
																													if($sm_proc_list)
																													foreach($sm_proc_list as $woHZoRlCs3vHhxnT9)
																													$woHZoRlCs3vHhxnT9->tCG0R0Wjs();
																													tRsLQ5oUyNb5($YH5ByymgQ21cHm,AEks4EOfaorM1XL(array('done'=>true)));
																													d82oX1fkf(array('cmd'=> 'info','id' => 'percprog',''));
																													}
																													function bQHeBmXjW0X($PVr4ajN4yAj3k)
																													{
																													for($i=0;file_exists($sf=TuLXmMBFSKj5mt.($_so=ZctF_GYww0IP2FS9v($i,$PVr4ajN4yAj3k).$this->R835G5lbvW9JfMRYGV));$i++){
																													SwIPpM21WDqv($sf);
																													SwIPpM21WDqv($this->furl_p.$_so);	    	
																													}
																													$gp = '.gz';
																													if($this->ybU_ViMnsXh['xs_compress']==2)
																													for($i=0;file_exists($sf=TuLXmMBFSKj5mt.ZctF_GYww0IP2FS9v($i,$PVr4ajN4yAj3k).$gp);$i++){
																													SwIPpM21WDqv($sf);
																													}
																													}
																													function D5fu2cOpBrzCWokB($dzCwKmg7mmN0ywa, $NG3NaNLQ50lQ4nEnR)
																													{
																													global $cYlf2voD22;
																													if(!@copy($dzCwKmg7mmN0ywa,$NG3NaNLQ50lQ4nEnR))
																													{
																													if($this->ybU_ViMnsXh['xs_filewmove'] && file_exists($NG3NaNLQ50lQ4nEnR) ){
																													SwIPpM21WDqv($NG3NaNLQ50lQ4nEnR);
																													}
																													if($cn = @cokTfdpvPOceFs7s($NG3NaNLQ50lQ4nEnR, 'w')){
																													@SEQKcL37vrK0KML0($cn, file_get_contents($dzCwKmg7mmN0ywa));
																													@fclose($cn);
																													}else
																													if(file_exists($dzCwKmg7mmN0ywa))
																													{
																													$cYlf2voD22[] = $NG3NaNLQ50lQ4nEnR;
																													}
																													}
																													
																													@chmod($dzCwKmg7mmN0ywa, 0666);
																													}
																													function v70BS5IEjKUP76o($PVr4ajN4yAj3k)
																													{
																													$gp = ($this->ybU_ViMnsXh['xs_compress']==2) ? '.gz' : '';
																													for($i=0;file_exists(TuLXmMBFSKj5mt.($sf=ZctF_GYww0IP2FS9v($i,$PVr4ajN4yAj3k).$this->R835G5lbvW9JfMRYGV));$i++){
																													$this->D5fu2cOpBrzCWokB(TuLXmMBFSKj5mt.$sf,$this->furl_p.$sf);
																													if($gp) {
																													$cn = file_get_contents(TuLXmMBFSKj5mt.$sf);
																													if(strstr($cn, '<sitemapindex'))
																													$cn = str_replace('.xml</loc>', '.xml.gz</loc>', $cn);
																													tRsLQ5oUyNb5(TuLXmMBFSKj5mt.$sf, $cn, '', true);
																													$this->D5fu2cOpBrzCWokB(TuLXmMBFSKj5mt.$sf.$gp,$this->furl_p.$sf.$gp);
																													}
																													}
																													}
																													function gcgzEV0dqv7gfUP($PVr4ajN4yAj3k, $Sq_33Gx1GflT = -1, $jpGoELQB14dycvnHu = '', $L09ejYxM52UFE = 0)
																													{
																													$cn = '';
																													$_fold = (strstr($PVr4ajN4yAj3k,'/')||strstr($PVr4ajN4yAj3k,'\\')) ? '' : TuLXmMBFSKj5mt ;
																													$_fapp = ($L09ejYxM52UFE ?  '' : $this->R835G5lbvW9JfMRYGV);
																													for($i=0;file_exists($sf=$_fold.ZctF_GYww0IP2FS9v($i,$PVr4ajN4yAj3k).$_fapp);$i++)
																													{
																													
																													if(@filesize($sf)<100000000)// 100MB max
																													$cn .= $_fapp?implode('',gzfile($sf)):Zx6LBsBDu($sf);
																													if($i>200)break;
																													}
																													$vhGsa_SffK = array(
																													array('loc', 'news:publication_date', 'priority'),
																													array('link', 'pubDate', ''),
																													);
																													$mt = $vhGsa_SffK[$L09ejYxM52UFE];
																													preg_match_all('#<'.$mt[0].'>(.*?)</'.$mt[0].'>'.
																													(($Sq_33Gx1GflT>=0) ? '.*?<'.$mt[1].'>(.*?)</'.$mt[1].'>' : '').
																													(($jpGoELQB14dycvnHu && $mt[2])? '.*?<'.$mt[2].'>(.*?)</'.$mt[2].'>' : '').
																													'#is',$cn,$um);
																													$al = array();
																													foreach($um[1] as $i=>$l)
																													{             
																													if($jpGoELQB14dycvnHu){
																													if(!strstr($l, $jpGoELQB14dycvnHu))
																													continue;
																													$l = substr($l, strlen($jpGoELQB14dycvnHu));
																													}
																													if(!$l)continue;
																													if($Sq_33Gx1GflT<=0) {
																													if($um[2][$i])
																													$al[$l] = $um[2][$i];
																													else
																													$al[$l]++;
																													}
																													else
																													if(time()-strtotime($um[2][$i])<=$Sq_33Gx1GflT*24*3600)
																													$al[$l] = $um[2][$i];
																													}
																													return $al;
																													}
																													function P4HUIj89_XK8FkoMcp($PVr4ajN4yAj3k, $hjE3G0r_YhC)
																													{
																													$cn = '';
																													$_fold = (strstr($PVr4ajN4yAj3k,'/')||strstr($PVr4ajN4yAj3k,'\\')) ? '' : TuLXmMBFSKj5mt ;
																													$_fapp = ($L09ejYxM52UFE ?  '' : $this->R835G5lbvW9JfMRYGV);
																													for($i=0;file_exists($sf=$_fold.ZctF_GYww0IP2FS9v($i,$PVr4ajN4yAj3k).$_fapp);$i++)
																													{
																													
																													if(@filesize($sf)<100000000)// 100MB max
																													$cn .= $_fapp?implode('',gzfile($sf)):Zx6LBsBDu($sf);
																													if($i>200)break;
																													}
																													preg_match_all('#<url[^>]*>(.*?)</url>#is',$cn,$um);
																													$al = array();
																													foreach($um[1] as $i=>$l)
																													{             
																													if(preg_match('#<loc[^>]*>(.*?)</loc>#is',$l,$qQG5eP9d_W8Y))
																													{
																													$gvSG5m7CocxBcv = array();
																													preg_match_all('#<'.$hjE3G0r_YhC.'[^>]*>(.*?)</'.$hjE3G0r_YhC.'>#is',$l,$M9JXawX6EHJCEbY3yd1);
																													foreach($M9JXawX6EHJCEbY3yd1[1] as $i=>$l2)
																													{             
																													$gvSG5m7CocxBcv[$l2]++;
																													}
																													if($gvSG5m7CocxBcv){
																													$al[$qQG5eP9d_W8Y[1]] = $gvSG5m7CocxBcv;
																													}
																													}
																													}
																													return $al;
																													}
																													}
																													global $Zd7mZmHqL;
																													$Zd7mZmHqL = new XMLCreator();
																													}
																													



































































































