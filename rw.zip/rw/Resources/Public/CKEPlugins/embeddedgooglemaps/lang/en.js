﻿CKEDITOR.plugins.setLang( 'embeddedgooglemaps', 'en', {
    title: 'Embedded Google Maps Properties',
    toolbar: 'Embedded Google Maps',
    latitude: 'Latitude',
    longitude: 'Longitude',
    altText: 'Alternative text',
    inputPlaceholder: 'If not provided record value will be used as default',
    inputPlaceholderAltText: 'If not provided record location value will be used as default',
    pathName: 'embeddedgooglemaps'
} );