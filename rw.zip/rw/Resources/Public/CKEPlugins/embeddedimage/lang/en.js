﻿CKEDITOR.plugins.setLang( 'embeddedimage', 'en', {
    title: 'Embedded Image Properties',
    toolbar: 'Embedded Image',
    contentKey: 'Content Key',
    contentKeyNotEmpty: 'Content Key field cannot be empty.',
    maxWidth: 'Max Width in pixels',
    maxWidthInteger: 'Max Width must be an number value.',
    borderBox: 'Border box?',
    pathName: 'embeddedimage'
} );