﻿CKEDITOR.plugins.setLang( 'embeddedtwitter', 'en', {
    title: 'Embedded Twitter Properties',
    toolbar: 'Embedded Twitter',
    content: 'Content',
    contentNotEmpty: 'Content field cannot be empty.',
    link: 'Link',
    explosionColor: 'Explosion Color',
    explosionColorRed: 'Red',
    explosionColorGreen: 'Green',
    explosionColorGray: 'Gray',
    pathName: 'embeddedtwitter'
} );