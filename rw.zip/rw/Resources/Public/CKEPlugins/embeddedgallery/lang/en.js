﻿CKEDITOR.plugins.setLang( 'embeddedgallery', 'en', {
    title: 'Embedded Gallery Properties',
    toolbar: 'Embedded Gallery',
    contentKey: 'Content Key',
    contentKeyNotEmpty: 'Content Key field cannot be empty.',
    pathName: 'embeddedgallery',
    maxWidth: 'Max Width in pixels',
    maxWidthInteger: 'Max Width must be an number value.'
} );