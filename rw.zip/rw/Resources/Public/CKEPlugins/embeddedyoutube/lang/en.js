﻿CKEDITOR.plugins.setLang( 'embeddedyoutube', 'en', {
    title: 'Embedded YouTube Properties',
    toolbar: 'Embedded YouTube',
    youtubeUrl: 'YouTube URL',
    youtubeUrlValid: 'YouTube URL must be a valid youtube link.',
    borderBox: 'Border box?',
    pathName: 'embeddedyoutube',
    alternativeText: 'Alternative text'
} );